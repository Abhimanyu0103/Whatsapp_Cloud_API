const https = require("https");

function SendMessageWhatsapp(data) 
{
    const options = {
        host: "graph.facebook.com",
        path: "/v19.0/175869718952302/messages",
        method: "POST",
        body: data,
        headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer EAAR8Ax105LkBO4AKSzZCKNEfiKaEYlbdwyIzqpVO8GdEDEkzb6m9Wu1SS3DAb5W01yYZB5UhVC4WSDCbVsst0r9AUS5jLOPNCBWqzjexcXnZCLyuqOOnjF64gBJ1v3SwK074FGkfB32vlDF7RG8pTPQZAsKiyfTbwag0ZCd9ULmWDEOeOXGJweONVZC8DdwSS2CqMvkRU1NwEitGfr1aL3"
        }
    };

    const req = https.request(options, res => {
        res.on("data", d => {
            process.stdout.write(d);
        });
    });

    req.on("error", error => {
        console.error(error);
    });

    req.write(data);
    req.end();
}

module.exports = {
    SendMessageWhatsapp
};
