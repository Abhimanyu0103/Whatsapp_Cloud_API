const expres = require("express");
const router = expres.Router();
const whatsappController = require("../controllers/whatsappController");

router
.get("/", whatsappController.VerifyToken)
.post("/",whatsappController.ReceivedMessage)

module.exports = router;