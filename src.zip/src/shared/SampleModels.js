function SampleText(textResponse, number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "text",
        "text": {
            "body": textResponse
        }
    });
    return data;
}

function SampleImage(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "image",
        "image": {
            "link": "https://i.imgur.com/BFCAkk0.jpg"
        }
    });

    return data;
}

function SampleVideo(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "video",
        "video": {
            "link": "https://www.e-connectsolutions.com/wp-content/uploads/2021/06/Eprashasan-Promo-Video-V3.mp4"
        }
    });

    return data;
}

function SampleDocument(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "document",
        "document": {
            "link":"https://docs.google.com/document/d/1tb1npm1fbTHNl03rrPfwsIulUzj0-SlrlOmLg9Veld8/edit?usp=sharing",
            "filename":"Ideation Pipeline PS"
        }
    });

    return data;
}

function SampleButtons(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "interactive",
        "interactive": {
        "type": "button",
        "body": {
            "text": "Are you currently working with us?"
        },
        "action": {
            "buttons": [
                {
                    "type": "reply",
                    "reply": {
                        "id": "001",
                        "title": "✅Yes"
                    }
                },
                {
                    "type": "reply",
                    "reply": {
                        "id": "002",
                        "title": "❌ No"
                    }
                }
            ]
        }
    }
    });

    return data;
}

function SampleList(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "interactive",
        "interactive": {
        "type": "list",
        "header": {
            "type": "text",
            "text": "Hello there! This is a feedback message for our company."
        },
        "body": {
            "text": "How was your experience at E-Connect Solutions Pvt. Ltd. "
        },
        "footer": {
            "text": "E-Connect Solutions Pvt. Ltd."
        },
        "action": {
            "button": "Please click here!",
            "sections": [
                {
                    "title": "Rate us!",
                    "rows": [
                        {
                            "id": "001",
                            "title": "Excellent",
                            "description": "I had the best experience here!"
                        },
                        {
                            "id": "002",
                            "title": "Good",
                            "description": "Could have been better!"
                        },
                        {
                            "id": "003",
                            "title": "Average",
                            "description": "I had high expectations"
                        }
                    ]
                }
            ]
        }
    }
    });

    return data;
}

function SampleLocation(number){
    const data = JSON.stringify({
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": number,
        "type": "location",
        "location": {
            "latitude": "24.57944896288114",
            "longitude": "73.7403879419429",
            "name": "E-Connect Solutions Pvt. Ltd.",
            "address": "G-18, 19, 20, IT Park, M.I.A., Udaipur"
        }
    });

    return data;
}

module.exports = {
    SampleText,
    SampleImage,
    SampleDocument, 
    SampleVideo,
    SampleButtons,
    SampleList,
    SampleLocation
};


