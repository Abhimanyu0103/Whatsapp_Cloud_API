const oracledb = require("oracledb");
const config = require("../connectivity/oracleConfig");

async function initialize() {
    try {
        await oracledb.createPool(config);
        console.log("Connection pool started");
    } catch (err) {
        console.error("Error initializing pool", err);
        process.exit(1);
    }
}

async function close() {
    try {
        await oracledb.getPool().close();
        console.log("Connection pool closed");
    } catch (err) {
        console.error("Error closing pool", err);
    }
}

module.exports = {
    initialize,
    close,
    oracledb
};

