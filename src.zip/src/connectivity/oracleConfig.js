const config = {
    user: "SIMSDEV",
    password: "SIMSDEV",
    connectString: "192.168.100.80/rajsims"
};

module.exports = config;

